title: Docker安装solo教程
date: '2019-08-22 22:21:26'
updated: '2019-09-23 17:30:24'
tags: [solo, docker]
permalink: /articles/2019/08/22/1566483686173.html
---
![](https://img.hacpai.com/bing/20181130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
## 引言
之前用war包部署过一次solo（超赞的开源博客系统），然后看solo的用户指南上说，推荐docker部署，就想把博客整的更完美一点，就学了一点docker。仅仅够我装个solo。
## 安装docker
[docker官方文档](https://docs.docker.com/install/linux/docker-ce/centos/)
这个是docker官方的安装文档，这个连接是centos版本的，可以在侧边栏选择其他的版本。然后跟着文档一步一步来就行了，这里以centos为例。
![image.png](https://img.hacpai.com/file/2019/08/image-b921dd8a.png)
1. 先卸载旧版本
```
$ sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
```
2. 添加repo
```
$ sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo
```
**中间的optional（可选的）直接跳过。**
3. 安装docker-ce
```
$ sudo yum install docker-ce docker-ce-cli containerd.io
```
这个步骤，我在安装的时候总是超时，安装不上，最后在网上找到的解决方法。根据下面这个链接把镜像站换成国内就行啦。[https://mirror.tuna.tsinghua.edu.cn/help/docker-ce/](https://mirror.tuna.tsinghua.edu.cn/help/docker-ce/)
4. 启动docker

```
$ sudo systemctl start docker
```
5. 验证docker是否安装成功
```
$ sudo docker -v
```
## 安装solo
1. solo的docker容器里面是没有mysql和nginx的，所以需要自己手动安装，docker容器里面只有java和maven环境。
2. 拉取solo镜像
```
$ docker pull b3log/solo
```
3. mysql建立solo数据库
4. 运行solo容器
```
$ sudo docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="数据库账号" \
    --env JDBC_PASSWORD="数据库密码" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=项目端口号 --server_scheme=http --server_host=localhost
``` 
这里是参考的solo官方安装指南，链接在下面
[https://github.com/b3log/solo](https://github.com/b3log/solo)
**注：安装指南在官方网页的在最下面**
## docker启动，使用其他皮肤或者图片
如果要使用其他皮肤或者图片，可以挂载目录 skins和images，在上面的运行命令的基础上，再加两行命令参数。
```
$ sudo docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="数据库账号" \
    --env JDBC_PASSWORD="数据库密码" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
 --volume /usr/local/solo/skins:/opt/solo/skins   \
 --volume /usr/local/solo/images:/opt/solo/images \
    b3log/solo --listen_port=项目端口号 --server_scheme=http --server_host=你的域名或者服务器ip地址
```
上面的/usr/local/solo/skins和/usr/local/solo/images是需要你手动建好的，然后就可以把solo默认的皮肤和图片复制到/usr/local/solo/skins和/usr/local/solo/images对应的文件夹下了，如果你有最新的皮肤，就可以直接把文件夹放在/usr/local/solo/skins下，就ok了。图片的404和图标的也是可以修改的。一定要将solo默认的皮肤拷过来，要不然启动会报找不着皮肤的异常。
