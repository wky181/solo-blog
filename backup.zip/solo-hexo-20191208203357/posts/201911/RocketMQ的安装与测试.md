title: RocketMQ的安装与测试
date: '2019-11-12 20:02:44'
updated: '2019-11-17 15:52:26'
tags: [RocketMQ]
permalink: /articles/2019/11/12/1573560164325.html
---
![](https://img.hacpai.com/bing/20171106.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)  
  
## RocketMQ简介  
RocketMQ是阿里巴巴2016年MQ中间件，使用**Java语言开发**，在阿里内部，RocketMQ承接了例如“双11”等高并发场景的消息流转，能够处理万亿级别的消息。  
## RocketMQ的安装  
点击[官方下载链接](http://rocketmq.apache.org/dowloading/releases/)，会看到RocketMQ的各个版本，目前最新的发行版是4.5.2，点击下载二进制文件进行安装。  
![image.png](https://img.hacpai.com/file/2019/11/image-03d20d56.png)。  
下载完后，将其放到要安装的服务器或虚拟机上，这里以linux系统为例。  
使用命令将其剪切到 /usr/local/ `mv rocketmq-all-4.5.2-bin-release.zip /usr/local/`,然后进行解压 `unzip rocketmq-all-4.5.2-bin-release.zip `。  
安装完成！## 启动RocketMQ  
1. 启动NameServer  
进入安装目录的bin文件夹下，执行命令`nohup sh mqnamesrv & ` 启动NameServer。使用`tail -f ~/logs/rocketmqlogs/namesrv.log `查看启动日志。  
  
![image.png](https://img.hacpai.com/file/2019/11/image-8d8579b1.png)  
表示启动成功。如果启动失败就先修改两个配置文件 runbroker.sh 和runserver.sh，这两个文件都在bin目录，先说明怎样改第一个配置文件 `vim runbroker.sh`，将里面的这三个JVM参数调低，-Xms256m -Xmx256m -Xmn128m。然后对于 runserver.sh 配置文件也做同样的更改。下图所示是更改位置。![image.png](https://img.hacpai.com/file/2019/11/image-8aa55da9.png)  
  
2. 启动Broker  
执行`nohup sh mqbroker autoCreateTopicEnable=true -n localhost:9876 &`启动Broker，`tail -f ~/logs/rocketmqlogs/broker.log `  
  
![image.png](https://img.hacpai.com/file/2019/11/image-397fdec7.png)  
  
启动成功！## 测试RocketMQ  
  
1、打开两个终端，分别进入MQ的bin目录，一个发消息，一个收消息。  
2、发消息端配置  
先设置环境变量，`export NAMESRV_ADDR=localhost:9876`，使用安装包的Demo发送消息 `sh tools.sh org.apache.rocketmq.example.quickstart.Producer`  
![image.png](https://img.hacpai.com/file/2019/11/image-aea4d5a1.png)正在发送消息ing。  
3、接受消息端配置  
先设置环境变量，`export NAMESRV_ADDR=localhost:9876`，接受消息 `sh tools.sh org.apache.rocketmq.example.quickstart.Consumer`  
![image.png](https://img.hacpai.com/file/2019/11/image-33d74f73.png)成功！此时发送端再执行发送消息命令，接受端就会自动打印第二次发送端发送的消息了。
