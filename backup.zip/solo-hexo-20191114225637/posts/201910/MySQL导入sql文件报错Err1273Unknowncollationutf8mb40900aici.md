title: 'MySQL导入sql文件报错 [Err] 1273 - Unknown collation: ''utf8mb4_0900_ai_ci'''
date: '2019-10-02 11:26:48'
updated: '2019-10-04 09:01:03'
tags: [脱坑, MySQL]
permalink: /articles/2019/10/02/1569986807956.html
---
![image.png](https://img.hacpai.com/file/2019/10/image-43b3d7f6.png)
最近将MySQL8导出的sql文件导入到MySQL5.7中时报错了，报的是 Unknown collation: 'utf8mb4_0900_ai_ci'，明明两个数据库的字符集(utf-8)和排序规则(utf8mb4_general_ci)都一样。结果在网上查找后，找到了方法，在这里mark一下。

处理方式就是把MySQL8导出的sql文件用记事本打开，把utf-8mb4全部替换为utf-8，把utf8mb4_0900_ai_ci全部替换为utf8_general_ci 。导入成功！
不过如果使用MySQL8.0.17以上版本，就不会出现上面的问题，这可能是MySQL的bug，后来修复了吧。


