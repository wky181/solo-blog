title: Linux下创建桌面快捷方式
date: '2019-11-08 22:49:22'
updated: '2019-11-09 09:08:36'
tags: [Linux]
permalink: /articles/2019/11/08/1573224562568.html
---
![](https://img.hacpai.com/bing/20190813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 引言
最近装了deepin操作系统，但是装过应用后，都要去bin文件启动，之前也用过ubuntu系统，创建过桌面图标，但是时间长给忘了，这次写篇博客记录一下。
Linux 系统中的Desktop Entry 文件以desktop为后缀名。Desktop Entry 文件是 Linux 桌面系统中用于描述程序启动配置信息的文件。   进入`/usr/share/applications` 目录，可见如下图所示的各类软件图标
![image.png](https://img.hacpai.com/file/2019/11/image-70a8d798.png)
从命名行打开可以看到都是以.desktop结尾的。
![image.png](https://img.hacpai.com/file/2019/11/image-0a9241ef.png)
## 具体操作
这里以idea为例：
1、在 `/usr/share/applications`目录下创建一个idea.desktop的文件
2、编辑这个文件
```
[Desktop Entry]
Encoding=UTF-8
Name=idea          
Comment=idea IDE       
Exec=/opt/ideaIU-2019.2/bin/idea.sh 
Icon=/opt/ideaIU-2019.2/bin/idea.png  
Terminal=false  
StartupNotify=false
Type=Application
Categories=Application;Development;
```
![image.png](https://img.hacpai.com/file/2019/11/image-e50e7526.png)

```
// 文件头（必须）
[Desktop Entry]

// 编码方式（可选）
Encoding=UTF-8

//程序名（必须）
Name = XXX

//图标（可选）
Icon=图标文件名（全称包含路径）

//执行脚本(必须)  (根据软件的具体执行路径修改)
Exec=脚本文件路径

//软件打开时是否启动终端
Terminal=false 

// 分类
Type=Application

// 鼠标经过上面时的提示名称
Comment=comment
```
3、把刚才创建的idea.desktop图标文件复制到桌面就行了。
