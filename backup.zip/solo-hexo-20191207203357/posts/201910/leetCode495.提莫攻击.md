title: leetCode 495. 提莫攻击
date: '2019-10-14 21:51:03'
updated: '2019-10-14 21:53:51'
tags: [日常肝题, 算法]
permalink: /articles/2019/10/14/1571061063379.html
---
## [提莫攻击](https://leetcode-cn.com/problems/teemo-attacking/)
在《英雄联盟》的世界中，有一个叫 “提莫” 的英雄，他的攻击可以让敌方英雄艾希（编者注：寒冰射手）进入中毒状态。现在，给出提莫对艾希的攻击时间序列和提莫攻击的中毒持续时间，你需要输出艾希的中毒状态总时长。
你可以认为提莫在给定的时间点进行攻击，并立即使艾希处于中毒状态。
示例1:

输入: [1,4], 2
输出: 4
原因: 在第 1 秒开始时，提莫开始对艾希进行攻击并使其立即中毒。中毒状态会维持 2 秒钟，直到第 2 秒钟结束。
在第 4 秒开始时，提莫再次攻击艾希，使得艾希获得另外 2 秒的中毒时间。
所以最终输出 4 秒。
倒序循环遍历
每次拿当前数的后一个数与中毒时间相减，得到预期的中毒点，如果当前数大于预期中毒点，那么当前数的中毒有效时间是前后数相减，否则就是所给的中毒时间，把每个数的中毒时间加起来就是结果。
```
 public static int findPoisonedDuration(int[] timeSeries,int duration){
        if (timeSeries.length ==0){
            return 0;
        }
        //记录总中毒时间
        int result = duration;
        //当前数的后一个数
        int perNumber = timeSeries [timeSeries.length -1];
        for (int i = timeSeries.length-2 ; i >=0 ; i--) {
            int targetNum = perNumber-duration;
            if (targetNum >= timeSeries[i]){
                result +=duration;
            }else {
                result +=perNumber-timeSeries [i];
                //下一个人当前数的后一个数
                perNumber = timeSeries[i];
            }
        }
        return result;
    }
```
