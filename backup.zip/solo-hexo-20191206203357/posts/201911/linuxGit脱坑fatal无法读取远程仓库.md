title: 'linux-Git脱坑 fatal: 无法读取远程仓库。'
date: '2019-11-21 17:37:47'
updated: '2019-11-22 08:34:44'
tags: [Git]
permalink: /articles/2019/11/21/1574329067692.html
---
![](https://img.hacpai.com/bing/20171229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 问题
最近装了deepin系统，感觉用着不错，界面很好看而且运行软件也比在windows上流畅很多。但是最近在使用git的时候遇到一个坑，记录一下。就是git clone 时候，使用普通用户克隆就会报`Permission denied (publickey).`的错误，一看到这个错误就知道是权限的问题，就用了 `sudo -i` 进行提权，然后项目克隆下载了，但是用idea打开不了项目，没有读写权限QAQ。最后发现是因为生成 ssh key的时候，用的是root用户，导致克隆下来的项目普通用户打不开。噗，我好沙雕(||๐_๐) 。
## 具体解决
1.删除原来的ssh key
先把在root用户下的 .ssh删除掉，`rm -r /root/.ssh/`，.ssh是隐藏的，可以用` ls -al ~/.ssh`,查看是否删除成功。出现无法访问'/root/.ssh': 没有那个文件或目录 表示删除成功。
2.创建新的ssh key
然后切换到普通用户下，生成ssh key。生成key的命令是：`ssh-keygen -trsa -C "youremail@example.com"`。把公匙放到码云或者github就行了。
