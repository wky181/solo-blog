title: Docker学习（一）入门篇
date: '2019-09-30 11:55:42'
updated: '2019-09-30 16:55:20'
tags: [docker]
permalink: /articles/2019/09/30/1569815742047.html
---
### 什么是Docker
Docker 是基于Go语言实现的开源容器项目。利用操作系统本身已有的机制和特性，可以实现远超传统虚拟机的轻量级虚拟化。它是内核级的虚拟化。期望达到使项目运行环境“一次封装，到处运行的目的”。
利用docker创建的运行环境叫做docker容器，容器是通过docker镜像创建的，docker镜像文件可以放在私有仓库中也可以放在共有仓库中。最大的公有仓库是官方[Docker Hub](https://www.docker.com/products/docker-hub)。
可以将Docker容器理解为一种轻量级的沙盒，每个容器内运行着一个应用，不同容器之间相互隔离，容器之间也可以通过网络互相通信。容器的创建和停止十分迅速，几乎和原生应用一样。
### 为什么要是用Docker
在云时代，开发者创建的应用必须要能很方便地在网络上部署，如果能够不受服务器的操作系统的影响和服务器是否安装应用所需环境，让应用在“任何时间任何地点”都是可快速部署的，这正是 Docker 所能够提供的最大优势 。
举个简单的例子，假设用户试图基于最常见的 LAMP (Linux+Apache+MySQL+PHP ）组合来构建网站 。 按照传统的做法，首先需要安装 Apache 、 MySQL 和 PHP 以及它们各自运 行所依赖的环境；之后分别对它们进行配置（包括创建合适的用户、配置参数等）；一旦需要服务器迁移（例如从阿里云迁移到其他云），往往需要对每个应用都进行重新部署和调试。极大地降低了用户的工作效率。究其根源，是这些应用直接运行在底层操作系统上，无法保证同一份应用在不同的环境中行为一致。而 Docker 提供了一种更为聪明的方式，通过容器来打包应用、解藕应用和运行平台 。这意味着迁移的时候，只需要在新的服务器上启动需要的容器就可以了，无论新旧服务器是否是同一类型的平台 。
### Docker的安装
[docker官方文档](https://docs.docker.com/install/linux/docker-ce/centos/)  
这个是docker官方的安装文档，这个连接是centos版本的，可以在侧边栏选择其他的版本。然后跟着文档一步一步来就行了，这里以centos为例。  
![image.png](https://img.hacpai.com/file/2019/08/image-b921dd8a.png?imageView2/2/w/1280/format/jpg/interlace/1/q/100)

1. 先卸载旧版本

```
$ sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine

```

2. 添加repo

```
$ sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo

```

**中间的optional（可选的）直接跳过。**  
3. 安装docker-ce

```
$ sudo yum install docker-ce docker-ce-cli containerd.io

```

这个步骤，我在安装的时候总是超时，安装不上，最后在网上找到的解决方法。根据下面这个链接把镜像站换成国内就行啦。[https://mirror.tuna.tsinghua.edu.cn/help/docker-ce/](https://mirror.tuna.tsinghua.edu.cn/help/docker-ce/)  
4. 启动docker

```
$ sudo systemctl start docker

```
5.  验证docker是否安装成功

```
$ sudo docker -v
```
## Hello World
Docker安装成功后，按照以下代码运行，就会打印出  Hello from Docker!，具体是怎么一回事，我们以后会讲。
```
docker pull hello-world
docker run hello-world
```
![image.png](https://img.hacpai.com/file/2019/09/image-07775373.png)

