title: Docker学习（二）Image的相关概念以及操作
date: '2019-11-04 11:43:56'
updated: '2019-11-05 21:54:37'
tags: [docker]
permalink: /articles/2019/11/04/1572839036081.html
---
![](https://img.hacpai.com/bing/20190304.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 什么是Image
* 文件和meta data的集合(root filesystem)
* 分层的，并且每一层都可以添加改变删除文件，**成为一个新的image**
* 上层的image可以共享下层image的环境的
* Image本身是read-only的
![5CWQ1S3287XBSPM.png](https://img.hacpai.com/file/2019/11/5CWQ1S3287XBSPM-9caa1350.png)

root filesystem 就是基于linux内核的发行版系统，比如ubuntu，centos等，用来当做baseImage,而bootft是linux内核，是所有image共享的。在baseImage上做增删该查的任何操作，都会生成一层新的image。
## 获取image的两种方式
1. 从官方[Docker hub ](https://www.docker.com/products/docker-hub)拉取image（貌似需要注册登录）。 
上一篇已经拉取过hello-world的镜像，这次使用`docker pull ubuntu:18:04`就可以拉取ubuntu的镜像了。：后面是版本号。这个和git像。
2. 使用dockerfile build 一个image
关键就是dockerfile，下面自己用dockerfile来创建一个image，首先准备一个编译好的hello-docker的c语言文件，c语言的源代码如下：
![image.png](https://img.hacpai.com/file/2019/11/image-f0675992.png)

然后对hello.c进行编译。

![image.png](https://img.hacpai.com/file/2019/11/image-dfc10c3d.png)

然后开始创建Dockerfile, 使用命令`vim Dockerfile`

![image.png](https://img.hacpai.com/file/2019/11/image-c73d763a.png)

第一步声明这是一个baseImage,第二步将当前目录的hello文件添加到Dockerfile的根目录。第三步就是执行hello文件的命令了。
然后执行 `docker build -t wky/hello-Docker .`，**-t为这个image贴上标签**,  **.代表当前目录。**

![image.png](https://img.hacpai.com/file/2019/11/image-e9ac3127.png)

使用dokcer的命令`docker images`看到多了一个image。

![image.png](https://img.hacpai.com/file/2019/11/image-a47ebde7.png)

然后再执行命令 `docker run wky/hello-docker` 运行一下。

![image.png](https://img.hacpai.com/file/2019/11/image-2671f11e.png)







