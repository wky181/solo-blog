title: win10搭建FTP服务器，实现局域网内上传下载文件
date: '2019-10-16 16:17:22'
updated: '2019-10-16 19:48:28'
tags: [FTP]
permalink: /articles/2019/10/16/1571213842260.html
---
![](https://img.hacpai.com/bing/20190206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 启动 IIS 服务和 FTP 服务器

首先打开控制面板，点击程序。
![image.png](https://img.hacpai.com/file/2019/10/image-6549e7a7.png)

![image.png](https://img.hacpai.com/file/2019/10/image-cc8d5b74.png)
按图中所示勾选选项，然后点击确定。

![image.png](https://img.hacpai.com/file/2019/10/image-b2f62eeb.png)

## 通过 IIS 搭建 FTP 站点
在搜索框里搜索IIS，出现下图所示：
![image.png](https://img.hacpai.com/file/2019/10/image-7b162bcc.png)

点击进入，添加FTP站点。

![image.png](https://img.hacpai.com/file/2019/10/image-a11e1a7d.png)

站点名字自己定义，然后选择一个文件夹，作为FTP服务器的目录。

![image.png](https://img.hacpai.com/file/2019/10/image-112d3b12.png)

点击下一步，选择本地Ipv4地址，无ssl,继续点击下一步。

![image.png](https://img.hacpai.com/file/2019/10/image-0d59fa47.png)

按照下图选项选完后，点击完成。

![image.png](https://img.hacpai.com/file/2019/10/image-f3535fde.png)

至此，ftp站点搭建完毕，本地电脑 ftp://+ip地址 可以正常访问。

![image.png](https://img.hacpai.com/file/2019/10/image-ee2bbc8b.png)
但是局域网的其它电脑还不能访问，因为有防火墙。
## 配置防火墙
控制面板-》系统安全-》防火墙

![image.png](https://img.hacpai.com/file/2019/10/image-3cdb7deb.png)
勾选关于ftp的选项 

![image.png](https://img.hacpai.com/file/2019/10/image-85f04e5a.png)
选择允许其它应用
![image.png](https://img.hacpai.com/file/2019/10/image-14378d5f.png)

如图添加路径

![73855GJEF6PIBW6OCQU2.png](https://img.hacpai.com/file/2019/10/73855GJEF6PIBW6OCQU2-7fe8af32.png)

最后点击应用。

然后设置入站规则
![image.png](https://img.hacpai.com/file/2019/10/image-51cb5c64.png)
启用关于FTP的规则
![image.png](https://img.hacpai.com/file/2019/10/image-5b23ec9b.png)
![image.png](https://img.hacpai.com/file/2019/10/image-4f5a2ea4.png)
至此，大功告成！
