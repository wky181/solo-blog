title: 我在 GitHub 上的开源项目
date: '2019-08-16 11:27:37'
updated: '2019-08-16 11:27:37'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [index-evaluation](https://github.com/AlgerFan/index-evaluation) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/AlgerFan/index-evaluation/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/AlgerFan/index-evaluation/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/AlgerFan/index-evaluation/network/members "分叉数")</span>

就业工作考核分析系统，用于分析《本科毕业生就业竞争力指数评价体系》的一整套系统，对生源质量指数、师资结构指数、就业状态指数、就业率指数、用人单位满意度指数、就业创业实践指数进行分析计算，数据一键导入，分析数据一键导出，最终通过导出总表的方式，完成对就业工作考核。



---

### 2. [solo-blog](https://github.com/wky181/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/wky181/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wky181/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wky181/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.wkyhky.site`](https://www.wkyhky.site "项目主页")</span>

wky233 的个人博客 - 记录精彩的程序人生



---

### 3. [arithmetic](https://github.com/wky181/arithmetic) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wky181/arithmetic/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wky181/arithmetic/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wky181/arithmetic/network/members "分叉数")</span>

记录自己做的算法题和学习一些数据结构

