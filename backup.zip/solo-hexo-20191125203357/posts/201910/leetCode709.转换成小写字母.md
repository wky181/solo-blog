title: leetCode 709. 转换成小写字母
date: '2019-10-14 20:51:57'
updated: '2019-10-14 20:51:57'
tags: [日常肝题, 算法, LeetCode]
permalink: /articles/2019/10/14/1571057517072.html
---
实现函数 ToLowerCase()，该函数接收一个字符串参数 str，并将该字符串中的大写字母转换成小写字母，之后返回新的字符串。
示例 1：
输入: "Hello"
输出: "hello"
示例 2：
输入: "here"
输出: "here"
示例 3：
输入: "LOVELY"
输出: "lovely"
链接：https://leetcode-cn.com/problems/to-lower-case
这道题其实很easy，但是我忘了大小写字母对应哪个数字了，在网上发现了一个快速查看字符对应数字的方法。
```
   for (int i = 0; i <255 ; i++) {
            char character = (char) i;
            System.out.println(i+": "+character+" ");
        }
```
没错就这么简单，我竟然没想到，，，😰 
顺便贴上这道题的答案吧。
```
public static String upCase(String str){
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c<91 && c>64){
                c = (char) (c+32);
            }
            result.append(c);
        }
        return result.toString();
    }
```
