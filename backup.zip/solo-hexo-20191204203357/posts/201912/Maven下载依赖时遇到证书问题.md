title: Maven下载依赖时遇到证书问题
date: '2019-12-03 18:00:46'
updated: '2019-12-03 18:02:58'
tags: [Maven, 脱坑]
permalink: /articles/2019/12/03/1575367246720.html
---
![](https://img.hacpai.com/bing/20181110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 遇到的问题
最近用IDEA打开了一个很久之前做的项目，发现需要重新导入Maven依赖，在依赖导入的时候报错如下：
```
could not transfer artifact org.springframework.boot:spring-boot-starter-parent:pom:2.0.4.RELEASE from/to nexus-aliyun (https://maven.aliyun.com/nexus/content/groups/public): PKIX path building failed: sun.security.provider.certpath.SunCertPathBuilderException: unable to find valid certification path to requested target
```
意思大致是在java库中没有找到 https://maven.aliyun.com/ 的证书。下面是我的Maven使用的阿里云的镜像库。
```
        <mirror>
            <id>nexus-aliyun</id>
            <mirrorOf>central</mirrorOf>
            <name>Nexus aliyun</name>
            <url>http://maven.aliyun.com/nexus/content/groups/public</url>
        </mirror>
```
## 解决方案
### 更换为https的阿里云镜像库
```
        <mirror>
            <id>nexus-aliyun</id>
            <mirrorOf>central</mirrorOf>
            <name>Nexus aliyun</name>
            <url>http://maven.aliyun.com/nexus/content/groups/public</url>
        </mirror>
```
### 下载安装阿里云的证书
用谷歌浏览器访问 [https://maven.aliyun.com/nexus/content/groups/public/](https://maven.aliyun.com/nexus/content/groups/public/)
1、点击链接左边的小锁，然后点击证书。 
![image.png](https://img.hacpai.com/file/2019/12/image-d386de45.png)
2、点击详细信息，再点击复制证书，之后就连续点击下一步，最后选择自己电脑的一个文件夹存放下载的证书，这里我下载到了d盘，文件命名为ali。

![image.png](https://img.hacpai.com/file/2019/12/image-90254aa9.png)

3、把证书添加到java信任证书库

**使用管理员权限打开cmd**，切换到：`{java安装根目录}\jre\lib\security`，把刚才下载的ali.cer证书放在`{java安装根目录}\jre\lib\security`目录下。运行命令`keytool -import -alias cacerts -keystore cacerts -file ali.cer`

![image.png](https://img.hacpai.com/file/2019/12/image-7b1b2b7f.png)

输入默认密码：**`changeit`**，这是java中cacerts证书库的默认密码。

![image.png](https://img.hacpai.com/file/2019/12/image-20fec536.png)

输入Y，信任此证书，至此，证书导入完成。

4、重新使用idea下载Maven依赖

点击package进行打包，强行下载依赖。

![image.png](https://img.hacpai.com/file/2019/12/image-2a19757f.png)

可以看到依赖正在下载，大功告成！

![image.png](https://img.hacpai.com/file/2019/12/image-4bfdaf31.png)



